$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Desktop/BDD/HotelMgmtWithValidation/src/test/java/Features/HotelMgmt.feature");
formatter.feature({
  "line": 1,
  "name": "Hotel booking Feature",
  "description": "I want to use this template for my feature file",
  "id": "hotel-booking-feature",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 5,
  "name": "Hotel Booking with valid details",
  "description": "",
  "id": "hotel-booking-feature;hotel-booking-with-valid-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "User is on hotel booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "enters all valid details",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "display succes page",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 11,
  "name": "FirstName is blank",
  "description": "",
  "id": "hotel-booking-feature;firstname-is-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 12,
  "name": "User is on hotel booking page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "firstname is blank and clicks on booking button",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "display error message for firstname field",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});